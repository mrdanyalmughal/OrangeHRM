# How do I report security vulnerabilities?

If you believe you have found a security vulnerability, please submit the report to our security team via [ossecurity@orangehrm.com](mailto:ossecurity@orangehrm.com).
